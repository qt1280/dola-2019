<?php
//
include ("library/checklogin.php");
    $operator = $_SESSION['operator_user'];
	
	include_once('library/config_read.php');
    $log = "visited page: ";
	$m_active = "appup";
	
	//连接数据库
    $conn= @mysql_connect('127.0.0.1','root','123456');
    mysql_select_db('radius',$conn);
    mysql_query('set character set  utf8');
    mysql_query('set names  utf8');

	if(isset($_POST['appname'])){
		//print_r($_POST);exit;
		$appname=$_POST['appname'];
		$apphao=isset($_POST['apphao'])?$_POST['apphao']:' ';
		
		if(isset($_FILES['afile'])){
			//print_r($_POST['file']);exit;
			//print_r($_FILES["afile"]["name"]);exit;
			$appfile=isset($_FILES["afile"])?$_FILES["afile"]["name"]:' ';
			move_uploaded_file($_FILES["afile"]["tmp_name"],"upfile/" . $_FILES["afile"]["name"]);
			copy("upfile/" . $_FILES["afile"]["name"],"../user/app/app.apk");
		}
		
		$appinfo=isset($_POST['appinfo'])?$_POST['appinfo']:' ';
		$status=isset($_POST['status'])?$_POST['status']:0;
		
		//加到数据库中
		$sql0="insert into appup (appname,apphao,appfile,appinfo,status) values ('$appname','$apphao','$appfile','$appinfo',$status)";
		$re0=mysql_query($sql0);
		
		if($re0){
			header("Location:app_up.php");
		}
		
	}
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>更新</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/1.css" type="text/css" media="screen,projection" />
</head>
 
		

	<div id="contentnorightbar" style="margin-left:10px;background:none;">
		
		<h2 id="Intro"><a href="#"><?php echo '更新APP' ?></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="/admin">返回主界面</a></h2>
		
		<p>
		<form method="post" enctype="multipart/form-data" action="" name="form1">
			<table>
				<tr>
					<td>版本名</td>
					<td>版本号</td>
					<td>app文件</td>
					<td width='120px'>app介绍</td>
					<td>状态</td>
					<td>下载地址</td>
                                        <td>动作</td>
				</tr>
				<?php
					$sql="select * from appup order by id desc";
					$re=mysql_query($sql);
					while($row=mysql_fetch_array($re)){
						//print_r($row);
						?>
				<tr>
					<td><input name='appname' type='text' value="<?php echo $row[1];?>"></td>
					<td><input name='apphao' value="<?php echo $row[2];?>" type='text'/></td>
					<td><input name='appfile' value='<?php echo $row[3];?>' type='text'/></td>
					<td><textarea name='appinfo'><?php echo $row[4];?></textarea></td>
					<td>未启用:<input name='status<?php echo $row[0];?>' value='0' type='radio' <?php echo $row['status']==0?'checked':''?>/>启用:<input name='status<?php echo $row[0];?>' value='1' type='radio' <?php echo $row['status']==1?'checked':''?>/></td>
                                        <td><a href="/admin/upfile/<?php echo $row[3];?>">http://121.18.238.5:8080/admin/upfile/<?php echo $row[3];?></a></td>
					<td><a href="delappup.php?id=<?php echo $row[0];?>">删除</a></td>
				</tr>
				<?php
					}
				?>
				<form method='post' enctype="multipart/form-data">
				<tr>
					<td><input name='appname' value='' type='text'/></td>
					<td><input name='apphao' value='' type='text'/></td>
					<td><input name='afile'  type='file'/></td>
					<td><textarea name='appinfo'></textarea></td>
					<td>不启用:<input name='status' value='0' type='radio'/>&nbsp;启用:<input name='status' value='1' type='radio'/></td>
					<td><input value='增加' type='submit'/></td>
				</tr>
				</form>
				<tr><td colspan="5">上传时请耐心等待，请勿操作此页任何区域，上传完成会自动刷新更新到第一行！</td></tr>
			</table>
			
		</p>


<?php
	include('include/config/logging.php');
?>

		</div>

		<div id="footer">
		
<?php
	include 'page-footer.php';
?>


		</div>

</div>
</div>

</body>
</html>

