<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>用户中心</title>
  <meta name="keywords" content=""/>
  <meta name="description" content=""/>
  <link href="css/bootstrap.min.css" rel="stylesheet"/>
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<?php
//检查用户
	function checkUsername($str)
	{
			$output='';
			$a=preg_match('/['.chr(0xa1).'-'.chr(0xff).']/', $str);
			$b=preg_match('/[0-9]/', $str);
			$c=preg_match('/[a-zA-Z]/', $str);
			if($a && $b && $c){
				$output='汉字数字英文的混合字符串';
			}elseif($a && $b && !$c){
				$output='汉字数字的混合字符串';
			}elseif($a && !$b && $c){
				$output='汉字英文的混合字符串';
			}elseif(!$a && $b && $c){
				$output='数字英文的混合字符串';
				return true;
			}elseif($a && !$b && !$c){
				$output='纯汉字';
				return true;
			}elseif(!$a && $b && !$c){
				$output='纯数字';
				return true;
			}elseif(!$a && !$b && $c){
				$output='纯英文';
				return true;
			}
			//return $output;
			return false;
	}
function check_username_pwd($username, $pwd){
    $query_sql = "SELECT * FROM radcheck WHERE username = '$username'";
    $re=mysql_query($query_sql);
    if($row=mysql_fetch_array($re)){
          $db_username = $row[1];
          $db_attribute = $row[2];
          $db_op = $row[3];
          $db_value = $row[4];
          if ($username == $db_username){
              if ($db_attribute == 'Cleartext-Password' || $db_attribute == 'User-Password'){
                  if ($db_value == $pwd)
                      return true;
              }
          }
        }else{
        return false;
    }

}
//获取流量
function get_user_used_traffic($username){
    $query_sql = "SELECT SUM(acctinputoctets + acctoutputoctets) FROM radacct WHERE username = '$username'";
    $re=mysql_query($query_sql);
    if($row=mysql_fetch_array($re)){
        if ($row[0] <> ''){
                return $row[0];
        }else{
                return 0;
        }
    }else{
        return false;
    }
}
//
function get_user_used_days($username){
    $query_sql = "SELECT IF(COUNT(radacctid>=1),(UNIX_TIMESTAMP() - IFNULL(UNIX_TIMESTAMP(AcctStartTime),0)),0) DIV 86400 FROM radacct WHERE username = '$username' AND AcctSessionTime >= 1 ORDER BY AcctStartTime LIMIT 1";
    $re=mysql_query($query_sql);
    if($row=mysql_fetch_array($re)){
        return $row[0];
    }else{
        return false;
    }

}
//
function get_user_total_traffic($username){
    $max_global_traffic = 0;
    $max_active_days = 0;
    $query_sql = "SELECT groupname FROM radusergroup WHERE username = '$username'";
    $re=mysql_query($query_sql);
    if($row=mysql_fetch_array($re)){
        $groupname = $row[0];
          $query_sql1 = "SELECT * FROM radgroupcheck WHERE groupname = '$groupname'";
          $re1=mysql_query($query_sql1);
          while($row1=mysql_fetch_array($re1)){
              if ("Max-Global-Traffic" == $row1[2]){
                  $max_global_traffic = $row1[4];
              }elseif("Max-Active-Days" == $row1[2]){
                  $max_active_days = $row1[4];
              }
          }

    }
    $max=array();
    $max[0]=$max_global_traffic;
    $max[1]=$max_active_days;
    return $max;

}
//主程序
    $username = $_POST['username'];
    $pwd = $_POST['password'];
    
    $data=array();
    if(empty($username) or empty($pwd ) ){//判断数值是否为空，如果为空则返回查询界面！
        $data['message']= urlencode();
        echo urldecode($data['message']);
		//echo "<script>alert('您好像没有输入账号或者密码哦~')</script>";
		header("Location: index.html"); 
        exit;
    }
    else {
        if(checkUsername($username) and checkUsername($pwd)){//判断用户是否使用非法代码！
        //连接数据库
        $conn= @mysql_connect('localhost','radius','hehe123');
		//博雅DALO专属！请勿修改版权！谢谢！官网：http://www.52hula.cn QQ:2223139086
		//提供源码给你们！请要点脸！别他妈吧版权改成你的！
		if($conn){//判断数据库是否连接成功！
		}else{
			echo "<script>alert('网页正在维护中！请稍后再试！')</script>";
			echo "<script>history.go(-1);</script>";
			exit;
		}
		
        mysql_select_db('radius',$conn);
        mysql_query('set character set  utf8');
        mysql_query('set names  utf8');
        	if (check_username_pwd($username,$pwd)){
                	//分配数据
                	$cur_traffic = get_user_used_traffic($username);
                	$data['globalTrafficCount'] = round($cur_traffic/1024/1024/1024,2);
                	//echo $cur_traffic;exit;
                	$umax = get_user_total_traffic($username);
                	$max_global_traffic= round($umax[0]/1024,2);
                	$max_active_days=$umax[1];
	                //echo $max_global_traffic.$max_active_days;exit;
        	        $data['maxGlobalTraffic'] = $max_global_traffic;
	                $data['maxActiveDays'] =$max_active_days;
        	        //echo $max_active_days;exit;
	                $data['activeDaysCount'] =get_user_used_days($username);
        	        mysql_close($conn);
        	}
	        else {
	                $data['message']= urlencode();
					echo urldecode($data['message']);
					echo "<script>alert('用户或密码输入不正确')</script>";
					echo "<script>history.go(-1);</script>";
					exit;
        	}
	}
	else {
                        $data['message']= urlencode();
						echo urldecode($data['message']);
						echo "<script>alert(检测到您使用了非法代码,拒绝操作！)</script>";
						echo "<script>history.go(-1);</script>";
			exit;
         }
	}
?>
<div class="container" style="padding-top:180px;">
<?php
/*    echo "账户:".$username."</br>";
    echo "已用流量:".urldecode($data['globalTrafficCount'])."G</br>";
    echo "总流量:".urldecode($data['maxGlobalTraffic'])."G</br>";
    echo "已用天数:".urldecode($data['activeDaysCount'])."天</br>";
    echo "总天数:".urldecode($data['maxActiveDays'])."天</br>";
*/
date_default_timezone_set('PRC');//使用PHP的date函数获取时间之前，先将时区设置为北京时区
if (urldecode($data['maxGlobalTraffic']) == "0"){
		$syll = "无限";
	}else{
		$syll = urldecode($data['maxGlobalTraffic']) - urldecode($data['globalTrafficCount'])."GB";
	}
if (urldecode($data['globalTrafficCount']) == "0"){
	$zhanghzz = '未激活';
}else{
	$zhanghzz = '已激活';
}
?>
   <table class="table">
      <tr><td>账号:<span class="label label-success"><?php echo $username;?></span></td></tr>
	  <tr><td>状态:<span class="label label-success"><?php echo $zhanghzz;?></span></td></tr>
      <tr><td>已用流量:<span class="label label-info"><?php echo urldecode($data['globalTrafficCount']);?>GB</span></td></tr>
      <tr><td>总流量:<span class="label label-info"><?php echo urldecode($data['maxGlobalTraffic']);?>GB</span></td></tr>
	  <tr><td>剩余流量:<span class="label label-info"><?php echo $syll;
	  //剩余流量 总流量减去已用流量得出结果?></span></td></tr>
    <tr><td>总天数:<span class="label label-danger"><?php echo urldecode($data['maxActiveDays']);?>天</span></td></tr>
	<tr><td>已用天数:<span class="label label-danger"><?php echo urldecode($data['activeDaysCount'])." day";
	//echo "<br>当前时间为:".date('Y-m-d H:i:s');
	//到期时间是在当前服务器时间上添加时间，如果服务器时间不准这个当然就不准了~?></span></td></tr>
   </table>
</div>
<!-- 博雅DALO专属！请勿修改版权！谢谢！官网：http://www.52hula.cn QQ:2223139086-->
<!-- 提供源码给你们！请要点脸！别他妈吧版权改成你的！-->
</body>
</html>
