<?php if(!defined('INCLUDE_PATH')){die('error!this is a cache file!');};?>﻿</body>
</html>