-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: radius
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alipay`
--

DROP TABLE IF EXISTS `alipay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alipay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `partner` text NOT NULL,
  `alikey` text NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alipay`
--

LOCK TABLES `alipay` WRITE;
/*!40000 ALTER TABLE `alipay` DISABLE KEYS */;
INSERT INTO `alipay` VALUES (1,'','','');
/*!40000 ALTER TABLE `alipay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_admin`
--

DROP TABLE IF EXISTS `app_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `op` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_admin`
--

LOCK TABLES `app_admin` WRITE;
/*!40000 ALTER TABLE `app_admin` DISABLE KEYS */;
INSERT INTO `app_admin` VALUES (1,'0','admin','boyadaloadmin');
/*!40000 ALTER TABLE `app_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_bbs`
--

DROP TABLE IF EXISTS `app_bbs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_bbs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `time` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `username` text NOT NULL,
  `to` text NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_bbs`
--

LOCK TABLES `app_bbs` WRITE;
/*!40000 ALTER TABLE `app_bbs` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_bbs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_config`
--

DROP TABLE IF EXISTS `app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `system` text NOT NULL,
  `qq` text NOT NULL,
  `top_content` text NOT NULL,
  `no_limit` text NOT NULL,
  `reg` int(11) NOT NULL,
  `col1` text NOT NULL,
  `col2` text NOT NULL,
  `col3` text NOT NULL,
  `col4` text NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_config`
--

LOCK TABLES `app_config` WRITE;
/*!40000 ALTER TABLE `app_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_daili`
--

DROP TABLE IF EXISTS `app_daili`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_daili` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `default` int(11) NOT NULL,
  `qq` text NOT NULL,
  `conetnt` text NOT NULL,
  `chongzhi` text NOT NULL,
  `name` text NOT NULL,
  `pass` text NOT NULL,
  `web` text NOT NULL,
  `show` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_daili`
--

LOCK TABLES `app_daili` WRITE;
/*!40000 ALTER TABLE `app_daili` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_daili` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_data`
--

DROP TABLE IF EXISTS `app_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` char(255) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `key` (`key`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_data`
--

LOCK TABLES `app_data` WRITE;
/*!40000 ALTER TABLE `app_data` DISABLE KEYS */;
INSERT INTO `app_data` VALUES (1,'TCP_PATH','res/user-status.txt'),(2,'UDP_PATH','res/user-status-udp.txt');
/*!40000 ALTER TABLE `app_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_gg`
--

DROP TABLE IF EXISTS `app_gg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_gg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `time` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`),
  KEY `id_3` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_gg`
--

LOCK TABLES `app_gg` WRITE;
/*!40000 ALTER TABLE `app_gg` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_gg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_qq`
--

DROP TABLE IF EXISTS `app_qq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_qq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `time` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`),
  KEY `id_3` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_qq`
--

LOCK TABLES `app_qq` WRITE;
/*!40000 ALTER TABLE `app_qq` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_qq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_read`
--

DROP TABLE IF EXISTS `app_read`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_read` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `readid` text NOT NULL,
  `time` text NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_read`
--

LOCK TABLES `app_read` WRITE;
/*!40000 ALTER TABLE `app_read` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_read` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_config`
--

DROP TABLE IF EXISTS `auth_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_config` (
  `id` varchar(80) NOT NULL DEFAULT '1',
  `gg` text,
  `ggs` text,
  `dl0` float DEFAULT NULL,
  `dl1` float DEFAULT NULL COMMENT 'vip1',
  `dl2` float DEFAULT NULL COMMENT 'vip2',
  `dl3` float DEFAULT NULL COMMENT 'vip3',
  `dl4` float DEFAULT NULL COMMENT 'vip4',
  `dl5` float DEFAULT NULL COMMENT 'vip5',
  `dls0` float NOT NULL,
  `dls1` float NOT NULL,
  `dls2` float NOT NULL,
  `dls3` float NOT NULL,
  `dls4` float NOT NULL,
  `dls5` float NOT NULL,
  `member_reg` int(2) NOT NULL DEFAULT '0',
  `regok` int(11) DEFAULT NULL,
  `activeok` int(11) DEFAULT NULL,
  `ok` int(11) DEFAULT NULL,
  `shopUrl` text NOT NULL,
  `shopCode` text NOT NULL,
  `daili_cash` float NOT NULL,
  `reg_cash` float NOT NULL,
  `user_cash` float NOT NULL,
  `qian` float NOT NULL,
  `user_endtime` int(11) NOT NULL,
  `wx0` float NOT NULL,
  `wx1` float NOT NULL,
  `wx2` float NOT NULL,
  `wx3` float NOT NULL,
  `wx4` float NOT NULL,
  `wx5` float NOT NULL,
  `kmtype` float NOT NULL DEFAULT '1' COMMENT '五期新增，1默认关闭自主设计套餐',
  `down` float DEFAULT '1' COMMENT '五期加入，1默认关闭下载',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_config`
--

LOCK TABLES `auth_config` WRITE;
/*!40000 ALTER TABLE `auth_config` DISABLE KEYS */;
INSERT INTO `auth_config` VALUES ('1','欢迎使用代理中心！','欢迎使用会员中心！',0,0,0,0,0,0,4,3.5,3,2.5,2,1.5,0,0,0,2,'http://www.917ka.com/Index.html','建议从数据库插入此代码',10,2.09715e+07,5.24288e+07,1.04858e+07,1,16,14,12,10,8,6,1,1);
/*!40000 ALTER TABLE `auth_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_daili`
--

DROP TABLE IF EXISTS `auth_daili`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_daili` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `tj_rmb` decimal(11,2) NOT NULL,
  `tj_user` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `rmb` decimal(11,2) NOT NULL DEFAULT '0.00',
  `vip` int(11) DEFAULT NULL,
  `kmlist` int(11) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `regdate` datetime DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `qq` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `buy` text NOT NULL,
  `buy2` text NOT NULL,
  `income` decimal(11,2) NOT NULL DEFAULT '0.00',
  `adtext` text NOT NULL,
  `adimg` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_daili`
--

LOCK TABLES `auth_daili` WRITE;
/*!40000 ALTER TABLE `auth_daili` DISABLE KEYS */;
INSERT INTO `auth_daili` VALUES (0,'0.00','','dmg','`echo $RANDOM`','0.00',5,NULL,1,'2016-08-29 11:19:46','管理员','123123','123456','http://www.917ka.com/','','0.00','','');
/*!40000 ALTER TABLE `auth_daili` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_fwq`
--

DROP TABLE IF EXISTS `auth_fwq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_fwq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `ipport` varchar(64) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_fwq`
--

LOCK TABLES `auth_fwq` WRITE;
/*!40000 ALTER TABLE `auth_fwq` DISABLE KEYS */;
INSERT INTO `auth_fwq` VALUES (1,'本机服务器','127.0.0.1:808','2016-12-08 10:12:42');
/*!40000 ALTER TABLE `auth_fwq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_kms`
--

DROP TABLE IF EXISTS `auth_kms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_kms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` tinyint(1) NOT NULL DEFAULT '1',
  `daili` int(11) NOT NULL DEFAULT '0',
  `km` varchar(64) DEFAULT NULL,
  `value` int(11) NOT NULL DEFAULT '0',
  `values` decimal(11,2) DEFAULT NULL,
  `money` decimal(11,2) DEFAULT '0.00',
  `isuse` tinyint(1) DEFAULT '0',
  `user` varchar(50) DEFAULT NULL,
  `usetime` datetime DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `kmtype_id` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `km` (`km`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_kms`
--

LOCK TABLES `auth_kms` WRITE;
/*!40000 ALTER TABLE `auth_kms` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_kms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_log`
--

DROP TABLE IF EXISTS `auth_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_log`
--

LOCK TABLES `auth_log` WRITE;
/*!40000 ALTER TABLE `auth_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banner`
--

DROP TABLE IF EXISTS `banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img1` text CHARACTER SET utf8 NOT NULL,
  `tit1` text CHARACTER SET utf8 NOT NULL,
  `info1` text CHARACTER SET utf8 NOT NULL,
  `img2` text CHARACTER SET utf8 NOT NULL,
  `tit2` text CHARACTER SET utf8 NOT NULL,
  `info2` text CHARACTER SET utf8 NOT NULL,
  `img3` text CHARACTER SET utf8 NOT NULL,
  `tit3` text CHARACTER SET utf8 NOT NULL,
  `info3` text CHARACTER SET utf8 NOT NULL,
  `daili` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner`
--

LOCK TABLES `banner` WRITE;
/*!40000 ALTER TABLE `banner` DISABLE KEYS */;
INSERT INTO `banner` VALUES (0,'http://i.niupic.com/images/2016/08/05/hn0fQC.jpg','超实惠流量冲浪新时代','抵制高价流量，让你使用专用的流量服务，从而价格远远低于运营商，安全快捷！','http://i.niupic.com/images/2016/08/08/29uhkR.jpg','支持IOS6-IOS10系统','一次安装永久支持续费，VPN连接100M服务器转接','http://i.niupic.com/images/2016/10/29/GDIIE8.jpg','安卓系统完美支持','操作人性化，流量软件上手很简单，使用仅需简单操作几步',0);
/*!40000 ALTER TABLE `banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kmtype`
--

DROP TABLE IF EXISTS `kmtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kmtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `days` float NOT NULL,
  `maxll` float NOT NULL,
  `dlid` float NOT NULL,
  `km_rmb` decimal(11,2) NOT NULL DEFAULT '0.00',
  `i` float NOT NULL COMMENT '代理充值套餐',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kmtype`
--

LOCK TABLES `kmtype` WRITE;
/*!40000 ALTER TABLE `kmtype` DISABLE KEYS */;
INSERT INTO `kmtype` VALUES (1,'超值5G流量特惠',30,5.24288e+06,0,'18.80',0),(2,'500充值额度',0,0,0,'500.00',1);
/*!40000 ALTER TABLE `kmtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `line`
--

DROP TABLE IF EXISTS `line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `line` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group` text CHARACTER SET utf8 NOT NULL,
  `name` text CHARACTER SET utf8 NOT NULL,
  `content` text CHARACTER SET utf8 NOT NULL,
  `type` text CHARACTER SET utf8 NOT NULL,
  `show` int(11) NOT NULL,
  `label` text CHARACTER SET utf8 NOT NULL,
  `time` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=670 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `line`
--

LOCK TABLES `line` WRITE;
/*!40000 ALTER TABLE `line` DISABLE KEYS */;
INSERT INTO `line` VALUES (1,'1','全国三网线路','# quote-configuration\r\n# Enables connection to GUI\r\nmanagement /data/data/de.blinkt.openvpn/cache/mgmtsocket unix\r\nmanagement-client\r\nmanagement-query-passwords\r\nmanagement-hold\r\n\r\nsetenv IV_GUI_VER &quot;de.blinkt.openvpn 0.6.17&quot; \r\nmachine-readable-output\r\nclient\r\nverb 4\r\nconnect-retry-max 5\r\nconnect-retry 5\r\nresolv-retry 60\r\n\r\ndev tun\r\n\r\n\r\nhttp-proxy-option EXT1 &quot;Host: www.52hula.cn&quot;\r\n\r\nudp 0 0 0.0.0.0:53 0.0.0.0:*\r\nudp 0 0 0.0.0.0:69 0.0.0.0:*\r\nudp 0 0 0.0.0.0:80 0.0.0.0:*\r\nudp 0 0 0.0.0.0:137 0.0.0.0:*\r\nudp 0 0 0.0.0.0:138 0.0.0.0:*\r\nudp 0 0 0.0.0.0:443 0.0.0.0:*\r\nudp 0 0 0.0.0.0:1194 0.0.0.0:*\r\nudp 0 0 0.0.0.0:3389 0.0.0.0:*\r\nudp 0 0 0.0.0.0:8080 0.0.0.0:*\r\n\r\n\r\nVlan-interface1 192.1.1.2 1000\r\nVlan-interface1 172.17.0.2 1000\r\nVlan-interface1 10.0.0.172 1000\r\nVlan-interface1 127.0.0.1 1000\r\nacl CONNECT method CONNECT\r\n\r\nproto udp\r\nremote 服务器IP地址 69\r\n\r\n\r\nauth-user-pass\r\n&lt;ca&gt;\r\n-----BEGIN CERTIFICATE-----\r\nMIIDyDCCAzGgAwIBAgIJAMMPpgLTPPACMA0GCSqGSIb3DQEBCwUAMIGfMQswCQYD\r\nVQQGEwJDTjELMAkGA1UECBMCWkoxCzAJBgNVBAcTAllEMRUwEwYDVQQKEwxGb3J0\r\nLUZ1bnN0b24xHTAbBgNVBAsTFE15T3JnYW5pemF0aW9uYWxVbml0MQswCQYDVQQD\r\nEwJjYTEQMA4GA1UEKRMHRWFzeVJTQTEhMB8GCSqGSIb3DQEJARYSbWVAbXlob3N0\r\nLm15ZG9tYWluMB4XDTE2MDQwODA4Mzk1N1oXDTI2MDQwNjA4Mzk1N1owgZ8xCzAJ\r\nBgNVBAYTAkNOMQswCQYDVQQIEwJaSjELMAkGA1UEBxMCWUQxFTATBgNVBAoTDEZv\r\ncnQtRnVuc3RvbjEdMBsGA1UECxMUTXlPcmdhbml6YXRpb25hbFVuaXQxCzAJBgNV\r\nBAMTAmNhMRAwDgYDVQQpEwdFYXN5UlNBMSEwHwYJKoZIhvcNAQkBFhJtZUBteWhv\r\nc3QubXlkb21haW4wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAK5K7bd0Mb/a\r\nKp6FCcY3HTxIE9fwaUFofLIyRdiMengDv+Iy44+SwIzwXW8Empo3/I7b87GwNGXW\r\n1Mi7sYx6O1yj4IDoGK6DXwm4roH5v4LT9PCbeCC+r1mhMRdcsCZXYLhnTz1ZP+ZS\r\nSgelwfZNQXhNO6kwfQxe6aYzXroAywX9AgMBAAGjggEIMIIBBDAdBgNVHQ4EFgQU\r\ne4hUGrEtghIYAMwDdogl1yN+N8swgdQGA1UdIwSBzDCByYAUe4hUGrEtghIYAMwD\r\ndogl1yN+N8uhgaWkgaIwgZ8xCzAJBgNVBAYTAkNOMQswCQYDVQQIEwJaSjELMAkG\r\nA1UEBxMCWUQxFTATBgNVBAoTDEZvcnQtRnVuc3RvbjEdMBsGA1UECxMUTXlPcmdh\r\nbml6YXRpb25hbFVuaXQxCzAJBgNVBAMTAmNhMRAwDgYDVQQpEwdFYXN5UlNBMSEw\r\nHwYJKoZIhvcNAQkBFhJtZUBteWhvc3QubXlkb21haW6CCQDDD6YC0zzwAjAMBgNV\r\nHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4GBAFIVIotU7ClrZLLxuLmC9N5JE0OQ\r\nwGNj6G0DmzU0GOyM5SLCgTenbtFL+eIEkw1/Wbic8IGRG9t3K3V0GAE/KAAtwApE\r\nF2+S6L8A3ienrvwjRzdlKMv9h3QuEp/XJD21T9kZKosPR4E2QBWgVCwO4Vba7fd/\r\nFKUvAiakVNWFWSiY\r\n-----END CERTIFICATE-----\r\n&lt;/ca&gt;\r\ncomp-lzo\r\n&lt;tls-auth&gt;\r\n#\r\n# 2048 bit OpenVPN static key\r\n#\r\n-----BEGIN OpenVPN Static key V1-----\r\na340b1145aba5c5c1513fbd3ebc50a12\r\n0b0a10f8f4250d4cba67db9275e1a3fb\r\nf081af8e0f8ae8e512237428eb491fb8\r\nd36b05cb4b41eb22eecd4f7577c6f280\r\n2e3debd3676865cbaacf3d40b60ee28b\r\n3b0302096aafc075f215488f0c4d4a27\r\n7e9d5af5d4c4085b559d790f1a78ded7\r\nf2c0488026bf6a15695b89c04119a86f\r\n481025d521e70f5755f8b2708699d751\r\n3f53b92555e782b0335b4ce58aca2c48\r\na43b3a798b19736ca3d57ef84b6d6768\r\n0a13dc9cca1562e344570e30d4c93ca1\r\neacb2a4a52d8292dbe99146d4ae60872\r\n8a78e2340c49da76e1894951c7e9c616\r\n70aa3decd9961c5cdc8ca11d3cc3e6aa\r\n4c50c7cf2743e858d6de1a03a9f23c31\r\n-----END OpenVPN Static key V1-----\r\n&lt;/tls-auth&gt;\r\nkey-direction 1\r\nroute-ipv6 ::/0\r\nroute 0.0.0.0 0.0.0.0 vpn_gateway\r\nremote-cert-tls server\r\n# Use system proxy setting\r\nmanagement-query-proxy','',1,'全国三网线路，博雅自带线路','1493455322');
/*!40000 ALTER TABLE `line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `line_copy2017`
--

DROP TABLE IF EXISTS `line_copy2017`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `line_copy2017` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` text CHARACTER SET utf8 NOT NULL,
  `content` text CHARACTER SET utf8 NOT NULL,
  `type` text CHARACTER SET utf8 NOT NULL,
  `group` text CHARACTER SET utf8 NOT NULL,
  `show` int(11) NOT NULL,
  `label` text CHARACTER SET utf8 NOT NULL,
  `time` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `line_copy2017`
--

LOCK TABLES `line_copy2017` WRITE;
/*!40000 ALTER TABLE `line_copy2017` DISABLE KEYS */;
/*!40000 ALTER TABLE `line_copy2017` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `line_grop`
--

DROP TABLE IF EXISTS `line_grop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `line_grop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_bin NOT NULL,
  `show` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `line_grop`
--

LOCK TABLES `line_grop` WRITE;
/*!40000 ALTER TABLE `line_grop` DISABLE KEYS */;
INSERT INTO `line_grop` VALUES (1,'中国移动',1,1),(2,'中国联通',1,1),(3,'中国电信',1,1);
/*!40000 ALTER TABLE `line_grop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `open`
--

DROP TABLE IF EXISTS `open`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open` (
  `id` varchar(50) NOT NULL,
  `type` float NOT NULL,
  `name` varchar(50) NOT NULL,
  `mo` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open`
--

LOCK TABLES `open` WRITE;
/*!40000 ALTER TABLE `open` DISABLE KEYS */;
/*!40000 ALTER TABLE `open` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `openvpn`
--

DROP TABLE IF EXISTS `openvpn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `openvpn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iuser` varchar(16) NOT NULL,
  `isent` bigint(128) DEFAULT '0',
  `irecv` bigint(128) DEFAULT '0',
  `maxll` bigint(128) NOT NULL,
  `pass` varchar(18) NOT NULL,
  `i` int(1) NOT NULL,
  `starttime` varchar(30) DEFAULT NULL,
  `endtime` int(11) DEFAULT '0',
  `dlid` int(11) DEFAULT NULL,
  `fwqid` int(11) DEFAULT '1',
  `notes` varchar(255) DEFAULT NULL,
  `tian` float NOT NULL COMMENT '大猫哥激活使用',
  `qian_date` date NOT NULL,
  `qian_num` float NOT NULL,
  `tj_user` text NOT NULL,
  `tj_ok` float NOT NULL,
  `by` int(11) NOT NULL DEFAULT '0' COMMENT '五期新增，0默认关闭该会员包月模式',
  PRIMARY KEY (`id`),
  KEY `iuser` (`iuser`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `openvpn`
--

LOCK TABLES `openvpn` WRITE;
/*!40000 ALTER TABLE `openvpn` DISABLE KEYS */;
/*!40000 ALTER TABLE `openvpn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `top`
--

DROP TABLE IF EXISTS `top`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `top` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `data` bigint(20) NOT NULL,
  `time` text NOT NULL,
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top`
--

LOCK TABLES `top` WRITE;
/*!40000 ALTER TABLE `top` DISABLE KEYS */;
/*!40000 ALTER TABLE `top` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `website`
--

DROP TABLE IF EXISTS `website`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `website` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `logo` text CHARACTER SET utf8 NOT NULL,
  `title` text CHARACTER SET utf8 NOT NULL,
  `app1` text CHARACTER SET utf8 NOT NULL,
  `app2` text CHARACTER SET utf8 NOT NULL,
  `qq` text CHARACTER SET utf8 NOT NULL,
  `tel` text CHARACTER SET utf8 NOT NULL,
  `ipinfo` text CHARACTER SET utf8 NOT NULL,
  `appleid1` text CHARACTER SET utf8 NOT NULL,
  `appleps1` text CHARACTER SET utf8 NOT NULL,
  `appleid2` text CHARACTER SET utf8 NOT NULL,
  `appleps2` text CHARACTER SET utf8 NOT NULL,
  `appleid3` text CHARACTER SET utf8 NOT NULL,
  `appleps3` text CHARACTER SET utf8 NOT NULL,
  `and_img1` text CHARACTER SET utf8 NOT NULL,
  `and_img2` text CHARACTER SET utf8 NOT NULL,
  `and_img3` text CHARACTER SET utf8 NOT NULL,
  `and_img4` text CHARACTER SET utf8 NOT NULL,
  `jia1` text CHARACTER SET utf8 NOT NULL,
  `jia2` text CHARACTER SET utf8 NOT NULL,
  `jia3` text CHARACTER SET utf8 NOT NULL,
  `jia4` text CHARACTER SET utf8 NOT NULL,
  `seo` text CHARACTER SET utf8 NOT NULL,
  `daili` float NOT NULL,
  `name` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `website`
--

LOCK TABLES `website` WRITE;
/*!40000 ALTER TABLE `website` DISABLE KEYS */;
/*!40000 ALTER TABLE `website` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-23 19:21:00
