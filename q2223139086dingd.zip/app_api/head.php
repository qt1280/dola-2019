   <?php
		require('system.php');
		$admin = db("app_admin")->where(array("username"=>$_SESSION["dd"]["username"],"password"=>$_SESSION["dd"]["password"]))->find();
		if(!$admin){
			if(!$login_allow){
				header("location:login.php?head=no");	
				exit;
			}
		
		}
		
		
?>
<!DOCTYPE html>
<html lang="cn" class="app">
<head>
<meta charset="utf-8" />
<title>叮咚流量卫士 云库系统</title>
<meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="css/app.v2.css" type="text/css" />
<link rel="stylesheet" href="js/calendar/bootstrap_calendar.css" type="text/css" cache="false" />
<script src="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
<!--[if lt IE 9]> <script src="js/ie/html5shiv.js" cache="false"></script> <script src="js/ie/respond.min.js" cache="false"></script> <script src="js/ie/excanvas.js" cache="false"></script> <![endif]-->
<link rel="stylesheet" href="/app_api/css/font-awesome.min.css">
</head>
<body>
<style type="text/css">
body,html{
	background:#efefef;
	padding:0px;margin:0px;height:100%;
	font-family: "Microsoft Yahei","Hiragino Sans GB","Helvetica Neue",Helvetica,tahoma,arial,Verdana,sans-serif,"WenQuanYi Micro Hei","\5B8B\4F53";
}
*{
	padding:0px;
	list-style:none;
}
.main-sidebar{
	
	height: 100%;
	min-height: 100%;
	width: 200px;
	z-index: 810;
	background-color: #2c2e2f;
	overflow-y:auto;
	overflow-x:auto;
 }

.header-logo{
	height: 70px;
    line-height: 70px;
    font-size: 12px;
    background: #2c2e2f;
    text-transform: uppercase;
    box-shadow: 1px 0px 2px rgba(0,0,0,0.2);
    border-bottom: 1px solid #ccc;
 }
 .container{
	
}
.content-main{
	background:#fff;
	padding:20px 20px;

}
.btn{
	    border-radius: 0px;
}
</style>
<?php
if(($_SESSION["dd"]["username"] == "admin" && $_SESSION["dd"]["password"] == "admin")|| strlen($_SESSION["dd"]["password"]) < 4 ){
	?>
	<!-- 模态框（Modal） -->
<div class="modal fade" id="anquan" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" 
						aria-hidden="true">×
				</button>
				<h4 class="modal-title" id="myModalLabel">
					安全信息警告
				</h4>
			</div>
			<div class="modal-body">
				<span class="glyphicon glyphicon-warning-sign" style="color: rgb(255, 38, 30); font-size: 34px;"> 风险警告</span><hr>

系统检测到您使用的是系统默认密码或者密码长度过短，这具有相当大的安全风险！请您立即 进入【系统设置】->【<a href="user.php">管理密码</a>】 修改密码！
<pre>
为了您的系统安全 请勿使用纯数字密码、简易密码、默认密码！这很容易被入侵！同时我们推荐您手动修改数据库管理地址phpmyadmin的文件名字。无论是不是随机!
</pre>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-primary" 
						data-dismiss="modal">我知道了
				</button>
				
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script>
$(function () { $('#anquan').modal({

})});
</script>
	<?php
}
?>