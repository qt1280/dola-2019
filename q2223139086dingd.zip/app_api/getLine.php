<?php
	require("system.php");
	$id = $_POST['id'];
	$u = $_POST["username"];
	$p = $_POST["password"];
  $ud=new MM($u,$p);
		if($ud->check()){
			$db = db(_openvpn_);
			$line = db('line')->where(array('id'=>$id))->find();	
			$data = array(
				'status'=>'success',
				'name'=>$line['name'],
				'type'=>$line['type'],
				'content'=>base64_encode(html_decode($line['content']))
			);
			die(json_encode($data));
		}else{
			$data = array(
				'status'=>'error',
				'msg'=>"您的身份信息未能经过验证"
			);
			die(json_encode($data));
		}