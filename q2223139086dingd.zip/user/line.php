<?php
/*function get_oss() {
    if (!empty($_SERVER['HTTP_USER_AGENT'])) {
        $os = $_SERVER['HTTP_USER_AGENT'];
        if (preg_match('/win/i', $os)) {
            $os = 'Windows';
        } else if (preg_match('/mac/i', $os)) {
            $os = 'MAC';
        } else if (preg_match('/linux/i', $os)) {
            $os = 'Linux';
        } else if (preg_match('/unix/i', $os)) {
            $os = 'Unix';
        } else if (preg_match('/bsd/i', $os)) {
            $os = 'BSD';
        } else {
            $os = 'Other';
        }
        return $os;
    } else {
        return 'unknow';
    }
}
function browse_infos() {
    if (!empty($_SERVER['HTTP_USER_AGENT'])) {
        $br = $_SERVER['HTTP_USER_AGENT'];
        if (preg_match('/MSIE/i', $br)) {
            $br = 'MSIE';
        } else if (preg_match('/Firefox/i', $br)) {
            $br = 'Firefox';
        } else if (preg_match('/Chrome/i', $br)) {
            $br = 'Chrome';
        } else if (preg_match('/Safari/i', $br)) {
            $br = 'Safari';
        } else if (preg_match('/Opera/i', $br)) {
            $br = 'Opera';
        } else {
            $br = 'Other';
        }
        return $br;
    } else {
        return 'unknow';
    }
}
$getss = get_oss()."".browse_infos();
if ($getss !== 'MACSafari'){
	 echo"<script>alert('请使用苹果自带浏览器(Safari浏览器)');history.go(-1);</script>";
	 exit;
}*/
include("../app_api/ssystem.php");
include('MM.class.php');

    $user = $_SESSION['username'];
    $pass = $_SESSION['password'];
    $ud = new MM($user,$pass);
    if(!$ud->check()){
    	echo "请登录";
    	header("location:login.php");
    }
?>


<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="utf-8"> 
<!-- 新 Bootstrap 核心 CSS 文件 -->
<link href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">

<!-- 可选的Bootstrap主题文件（一般不使用） -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap-theme.min.css"></script>

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js"></script>

<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<title>安装线路</title>
<style>
body,html{
	background:#efefef;
	padding:0px;
	margin:0px;
	overflow-x:hidden;
}
.main{
	margin:10px;
}
.list-group-item a{
	bold;
}
.label-t{
	margin-bottom:20px;
}
.line{
	height:1px;
	background:#ccc;
}
.btn{
	border-radius: 0px;

}
</style></head>
<?php
function getvip() {
    if (getenv("HTTP_CLIENT_IP"))
		$ip = getenv("HTTP_CLIENT_IP");
	else if(getenv("HTTP_X_FORWARDED_FOR"))
		$ip = getenv("HTTP_X_FORWARDED_FOR");
	else if(getenv("REMOTE_ADDR"))
		$ip = getenv("REMOTE_ADDR");
	else $ip = "Unknow";
	//return $ip;
    return $ip;
}


	$regionno = false;
	if(trim($_GET["s"]) == ""){
		if($_SESSION["is_tmp_location"] && $_GET["location"] != "true"){
			$region = $_SESSION["region"];
			$isp = $_SESSION["isp"];
		}else{
			$ip = getvip();
			$is_location = true;

			$api_uri = "http://ip.taobao.com/service/getIpInfo.php?ip=$ip";
			$json = file_get_contents($api_uri);
			$arr = json_decode($json,true);
			if($arr["code"] != "0"){
				$ispno = true;
			}
			$isp    = '中国'.$arr["data"]["isp"]; //运行商 eg 电信
			// 删除市区
			// if(strstr($arr["result"]["area"],'省')){
			// 	$area   = substr($arr["result"]["area"], 0, strpos($arr["result"]["area"],'省')+3);
			// }else{
			// 	$area   = $arr["result"]["area"];
			// }
			$region = $arr["data"]["region"]; //省份 eg 河北省
			//$city = $arr["data"]["city"]; //市区 eg 保定市
			$ip = getvip(); //用户IP eg 123.57.89.18
		}
		//$region =
	}else{
		$region = $_GET["s"];
		$isp = $_GET["i"];
		$_SESSION["region"] = $region;
		$_SESSION["isp"] = $isp;
		$_SESSION["is_tmp_location"] = true;
	}

	$find = str_replace("省","",$region);
	$find = str_replace("市","",$find);
	$find = str_replace("壮族自治区","",$find);
	$find = str_replace("维吾尔自治区","",$find);
	$find = str_replace("回族自治区","",$find);
	$find = str_replace("自治区","",$find);
	$line_grop = db('line_grop')->where(array("show"=>1))->order('id ASC')->select();
	?>
<style  type="text/css">
.auto{
	background:#fff;
	padding-left:10px;
	height:40px;
	line-height:40px;
	border-top:1px solid #ccc;
}

.box01_list{
	list-style:none;
	margin:0px;
	padding:0px;
}
.sx{
	background:#328cc9;
	color:#fff;
	border:none;
	height:40px;
	margin:0px;
	float:right;
}
.breadcrumb{
	margin:0px;
}
.tip{
	color:#999;font-size:14px;
	padding:5px 0px;
}
</style>

<form action="?" method="GET">
<div class="auto">
	地区<select name="s">
<?php if($region != ""){?>
<option value="<?php echo $region;?>"><?php echo $region;?></option>
<?php }?>
<option>不限地区</option>
<option>北京市</option>
<option>天津市</option>
<option>上海市</option>
<option>重庆市</option>
<option>河北省</option>
<option>山西省</option>
<option>山东省</option>
<option>辽宁省</option>
<option>吉林省</option>
<option>黑龙江省</option>
<option>江苏省</option>
<option>浙江省</option>
<option>安徽省</option>
<option>福建省</option>
<option>江西省</option>
<option>山东省</option>
<option>河南省</option>
<option>湖北省</option>
<option>湖南省</option>
<option>广东省</option>
<option>海南省</option>
<option>四川省</option>
<option>贵州省</option>
<option>云南省</option>
<option>陕西省</option>
<option>甘肃省</option>
<option>宁夏</option>
<option>广西</option>
<option>新疆</option>
<option>西藏</option>
<option>青海省</option>
<option>台湾省</option>
<option>香港</option>
<option>澳门</option>
	</select>
	运营商<select name="i">
		<?php
		$i = 1;
		$p = "";

		$select_id = $line_grop[0]['id'];
		foreach($line_grop as $vo){
			if(!$ispno){
				if($vo["name"] == $isp){
					$p = 'selected';
					$select_id = $vo["id"];
				}
				echo '<option value="'.$vo["name"].'" '.$p.'>'.$vo["name"].'</option>';
			}else{
				if($i == 1){
					$p = 'selected';
					$select_id = $vo["id"];
				}
				echo '<option value="'.$vo["name"].'" '.$p.'>'.$vo["name"].'</option>';
			}
			$i++;
			$p = "";
		}
		?>

	</select>
	<input type="submit" class="sx" value="筛选线路">
</div><ol class="breadcrumb">
    <li><a href="#"><?php echo $find == "" ? "不限地区" : $find?></a></li>
    <li><a href="#"><?php echo $isp  == "" ? "中国移动" : $isp?></a></li>
   


  
	
</form>
		<br># 若是系统判定错误[ <?php echo $region; ?>]， 请点    <li><a href="?act=line&key=<?php echo $_GET["app_key"] ?>&username=<?php echo $_GET["username"] ?>&password=<?php echo $_GET["password"] ?>&location=true">[更新定位]</a></li>
	</div>
<br>
	</div>
      <form action="?" method="GET">
          <div class="input-group" style="margin:0 10% 0 10%">
          	        <input name="act" value="line" type="hidden">
                    <input name="app_key" value="<?php echo $_GET["app_key"] ?>" type="hidden">
                    <input name="username" value="<?php echo $_GET["username"] ?>" type="hidden">
                    <input name="password" value="<?php echo $_GET["password"] ?>" type="hidden">
					<input name="s" value="<?php echo $find ?>" type="hidden">
					<input name="i" value="<?php echo $isp ?>" type="hidden">
          	        <input type="hidden" name="" value="q2223139086">
                    <input type="text" class="form-control" placeholder="请输入要搜索的线路关键词" name="q2223139086">
                    <span class="input-group-btn">
                        <input class="btn btn-default" type="submit" value="搜索" style="background:#bb00dd;border:#bb00dd">
                    </span>
                </div><!-- /input-group -->
              </form> 
    <div id="slider" class="swipe">

      <ul class="box01_list">

				<li class="li_list" style="<?php echo $ss?>">
				<!---->
					<div class="main">
					<ul class="list-group">
					<?php if($is_location){?>
					<center>
							<div class="tip">--=自动定位：<?php echo $find == "" ? "不限地区" : $region?><?php echo $isp  == "" ? "中国移动" : $isp?>=--</div>
						</center>
					<?php  };
					$show = false;
						if(trim($region) == "" || $region == "不限地区"){
							$line = db('line')->where(array('show'=>'1','group'=>$select_id))->order('id DESC')->select();
						}else{
							$show = true;
							if(str_length(urldecode($region)) > 8){
								die("参数过长 len:".str_length(urldecode($region)));
							}
						$qingyun = $_GET["q2223139086"];
						if($qingyun !== null){
							$line = db('line')->where("`show`=1 AND `group`=:select_id AND (label LIKE '%".$qingyun."%' OR name LIKE '%".$qingyun."%')",array(":select_id"=>$select_id))->order('id DESC')->select();
						}else{
							$line = db('line')->where("`show`=1 AND `group`=:select_id AND (label LIKE '%".$find."%' OR name LIKE '%".$find."%')",array(":select_id"=>$select_id))->order('id DESC')->select();
						}
							$line2 = db('line')->where("`show`=1 AND `group`=:select_id AND (label LIKE '%全国%' OR label LIKE '%通用%' OR label LIKE '%不限地区%' OR `name` LIKE '%全国%' OR `name` LIKE '%通用%' OR `name` LIKE '%不限地区%')",array(":select_id"=>$select_id))->order('id DESC')->select();
						}

						if($line){
							foreach($line as $vos){?>
							<center><li class="list-group-item"><b>
								<?php echo $vos['name']?></b>&nbsp;
								<span class="main"><?php echo $vos['type']?><badge></span>
								<br>
							<li class="list-group-item"><p><?php echo $vos['label']?></p></li>

						
								<a class="btn btn-primary btn-sm" style="width:310px;height:38px;" href="<?php echo"down.php?id=".$vos['id'];?>"><h5>安装线路</h5></a>
					

					
					</li></center>
						<?php }
						}else{
						?>
						<center>
							<div style="color:#ccc;font-size:12px;">暂无当前地区线路</div>
						</center>
						<?php
						}
						if($show){
						?>
						<center>
						<span style="color:#0000FF">——=以下为您推荐全国通用线路=——</span>
							
						</center>
						<?php foreach($line2 as $vos){?>
							<center><li class="list-group-item"><b>
								<?php echo $vos['name']?></b>&nbsp;
								<span class="main"><?php echo $vos['type']?><badge></span>
								<br>
							<li class="list-group-item"><p><?php echo $vos['label']?></p></li>
							
						
								<a class="btn btn-primary btn-sm" style="width:310px;height:38px;"  href="<?php echo"down.php?id=".$vos['id'];?>"><h5>安装线路</h5></a>
					

					
					</li></center>
						<?php }
						} ?>
					</ul>
					<div style="clear:both"></div>
				</div>
			</li>
      </ul>
</div>
