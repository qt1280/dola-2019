<?php
 // echo defined(_XL_);
?>



 