<?php
function get_os() {
    if (!empty($_SERVER['HTTP_USER_AGENT'])) {
        $os = $_SERVER['HTTP_USER_AGENT'];
        if (preg_match('/win/i', $os)) {
            $os = 'Windows';
        } else if (preg_match('/mac/i', $os)) {
            $os = 'MAC';
        } else if (preg_match('/linux/i', $os)) {
            $os = 'Linux';
        } else if (preg_match('/unix/i', $os)) {
            $os = 'Unix';
        } else if (preg_match('/bsd/i', $os)) {
            $os = 'BSD';
        } else {
            $os = 'Other';
        }
        return $os;
    } else {
        return 'unknow';
    }
}
function browse_info() {
    if (!empty($_SERVER['HTTP_USER_AGENT'])) {
        $br = $_SERVER['HTTP_USER_AGENT'];
        if (preg_match('/MSIE/i', $br)) {
            $br = 'MSIE';
        } else if (preg_match('/Firefox/i', $br)) {
            $br = 'Firefox';
        } else if (preg_match('/Chrome/i', $br)) {
            $br = 'Chrome';
        } else if (preg_match('/Safari/i', $br)) {
            $br = 'Safari';
        } else if (preg_match('/Opera/i', $br)) {
            $br = 'Opera';
        } else {
            $br = 'Other';
        }
        return $br;
    } else {
        return 'unknow';
    }
}
include("/var/www/html/app_api/ssystem.php");
include('MM.class.php');
 $id = $_GET['id'];
	$line = db('line')->where(array('id'=>$id))->find();
		$filename = $line['name'].'.ovpn';
if (preg_match("/MSIE/", $_SERVER['HTTP_USER_AGENT']) ) {
	  header("Content-Type: application/octet-stream");
    header('Content-Disposition:  attachment; filename="' . $encoded_filename . '"');
} elseif (preg_match("/Firefox/", $_SERVER['HTTP_USER_AGENT'])) {
	  header("Content-Type: application/octet-stream");
    header('Content-Disposition: attachment; filename*="utf8' .  $filename . '"');
  }elseif(preg_match("/iPhone/i", $_SERVER['HTTP_USER_AGENT'])){
  	header("Content-Type: application/force-download");
    header("Content-Disposition: attachment; filename=$filename");
  }  
 else {
	    header("Content-Type: application/octet-stream");
	    header('Content-Disposition: attachment; filename="' .  $filename . '"');
}
$gets = get_os()."".browse_info();
if ($gets !== 'MACSafari'){
	echo "�����ȡ��·������DALO http://www.52hula.cn/";
}else{
	echo html_entity_decode($line['content']);
	exit;
}
?>
