<?php
echo $_SESSION['username'];
?>


 