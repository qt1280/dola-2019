<?php
session_start();
include("MM.class.php");
?>
<html lang="cn" class="bg-dark">
<head>
<meta charset="utf-8" />
<title>登录到系统</title>

<meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="css/app.v2.css" type="text/css" />
<link rel="stylesheet" href="css/font.css" type="text/css" cache="false" />
</head>
<?php
function checkUsernam($str){
	$output='';
	$a=preg_match('/['.chr(0xa1).'-'.chr(0xff).']/', $str);
	$b=preg_match('/[0-9]/', $str);
	$c=preg_match('/[a-zA-Z]/', $str);
	if($a && $b && $c){
		$output='汉字数字英文的混合字符串';
	}elseif($a && $b && !$c){
		$output='汉字数字的混合字符串';
	}elseif($a && !$b && $c){
		$output='汉字英文的混合字符串';
	}elseif(!$a && $b && $c){
		$output='数字英文的混合字符串';
		return true;
	}elseif($a && !$b && !$c){
		$output='纯汉字';
		return true;
	}elseif(!$a && $b && !$c){
		$output='纯数字';
		return true;
	}elseif(!$a && !$b && $c){
		$output='纯英文';
		return true;
	}
	//return $output;
	return false;
}

if(isset($_POST["user"]) && isset($_POST["pass"])){
	$u = $_POST["user"];
	$p = $_POST["pass"];
	$ud = new MM($u,$p);
	//if(checkUsername($u) and checkUsername($p)){
	if(trim($u) == "" || trim($p) == ""){
		echo "<script>alert(\"账户密码不能为空\");</script>";
	}else{
	if($ud->check()){
		$_SESSION["username"] = $u;
		$_SESSION["password"] = $p;
		header("location:info.php");
	}else{
		echo "<script>alert(\"密码错误请重新输入\");</script>";
	}
	}//}else{
	//echo "禁止输入非法代码";
//}
}
if($_GET['act']=="logout"){
	  unset($_SESSION['username']);
    unset($_SESSION['password']);
    header("location:login.php");
}
?>


<style>
body,html{
	background:#fff;
	padding:0px;
	margin:0px;
	font-family:"微软雅黑"
}
*{
	font-family:"微软雅黑"
}

.login-view{
	height:100%;
	background:url("bg.jpg");
}
.login-box{
	width:400px;
	margin-top:250px;
	background:#fff;
	float:right;
}
.login-title{
	padding:18px 15px;
	font-size:18px;
	color:#333;
	border-bottom:1px solid #efefef;
}

.login-bottom{
	padding:15px 15px;
	font-size:18px;
	color:#333;
	border-top:1px solid #efefef;
	background:#f8f8f8;
	text-align:right;
}
@media screen and (max-width:768px){
	.login-box{
		width:100%;
		margin-top:10px;
		background:#fff;
		float:none;
	}
}
</style>
<div class="login-view ">
<section id="content" class="m-t-lg wrapper-md animated fadeInUp">
  <div class="container aside-xxl"> <a class="navbar-brand block view" href="info.php">个人中心系统登录</a>
    <section class="panel panel-default bg-white m-t-lg">
      <header class="text-center padder"> <big>登录</strong> </header>
	   <form action="./login.php" method="POST" class="panel-body wrapper-lg" role="form">
        <div class="form-group">
          <label class="control-label">用户名</label>
          <input type="text" placeholder="请输入您的帐号" class="form-control input-lg" name="user">
        </div>
        <div class="form-group">
          <label class="control-label">密码</label>
          <input type="password" id="inputPassword" placeholder="请输入您的密码" class="form-control input-lg" name="pass">
        </div>
			<button type="submit" class="btn btn-primary btn-block">登录到个人中心</button>

        <div class="line line-dashed"></div>
<!-- footer -->
<footer id="footer">
  <div class="text-center padder">
    <p> <small>DALO流量卫士版权所有<br>
      &copy; 2017</small> </p>
      </form>
    </section>
  </div>

</section>



 